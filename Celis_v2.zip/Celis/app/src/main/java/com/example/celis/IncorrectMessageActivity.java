package com.example.celis;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class IncorrectMessageActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_incorrect_message);
    }
}
